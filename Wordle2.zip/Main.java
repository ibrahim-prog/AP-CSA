import java.util.Scanner; 

class Main {
  public static void main(String[] args) {
    /* System.out.println("Guess word with exactly 5 characters!");
    Scanner sc = new Scanner(System.in);
    String word = sc.next();

    word = word.toUpperCase();
    */

    int count = 0;

    HiddenWord puzzle = new HiddenWord("DRAIN");

    while (count < 6) {
    
      System.out.println("Guess a word with exactly 5 characters!");
      Scanner sc = new Scanner(System.in);
      String word = sc.next();
      word = word.toUpperCase();

      if ((puzzle.getTarget()).equals(word)){
        count += 6;
        System.out.println("You guessed it!");
      }
      System.out.println(puzzle.getHint(word));
      
      count ++;
    }
        
  }

    // create a for loop here, with a condition that
    // count is less than 6, and within this loop,
    // should be the method calls

    // get rid of the static method stuff in the 
    // hiddenWord class
    
}
