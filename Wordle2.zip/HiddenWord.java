public class HiddenWord {
  private String target;
 
  public HiddenWord(String target)
  {
    this.target = target;
  }

  public String getTarget()
  {
    return target;
  }

  public String getHint(String guess)
  {
    String newWord = "";
  
      for (int i = 0; i<guess.length(); i++)
      {
        if ((guess.substring(i,i+1)).equals(target.substring(i,i+1)))
        {
          newWord += guess.substring(i, i+1);
        }
        else if (target.indexOf(guess.substring(i, i+1))  >= 0)
        {
          newWord += "+";
        }
        else if (target.indexOf(guess.substring(i, i+1))< 0)
        {
          newWord += "*";
        }
      }
      return newWord;
  }

//hi
}